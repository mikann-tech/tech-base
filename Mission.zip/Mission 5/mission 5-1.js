async function getPokemonData(pokemonName) {
  const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`)
  const data = await response.json()
  //console 上で data を表示する
  console.log(data); // コンソールにも表示

      // JSON文字列に整形してdivに表示
      document.getElementById("pokemonn").innerText = JSON.stringify(data, null, 2);
    }
 
getPokemonData('ditto')