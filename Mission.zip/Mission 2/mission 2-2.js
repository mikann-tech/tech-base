var object = document.getElementById('greeting');
var text = prompt('表記するメッセージ','挨拶を入力をしてください');
object.innerText = text;

