function omikujibottun(){
      var omikuji = new Array("大吉","中吉","小吉","末吉","凶","大凶","吉");
      var a = Math.random();
      console.log(a)

      var text = "";
      var Imge = "";

      if(a < 0.05){
        text = omikuji[0]
        Imge = "daikichi.jpg"
      }
      else if(a < 0.15){
        text = omikuji[1]
        Imge = "chuukichi.jpg"
      }
      else if(a < 0.35){
        text = omikuji[2]
        Imge = "syoukichi.jpg"
      }
      else if(a < 0.50){
        text = omikuji[3]
        Imge = "suekichi.jpg"
      }
      else if(a < 0.65){
        text = omikuji[4]
        Imge = "kyou.jpg"
      }
      else if(a < 0.80){
        text = omikuji[5]
        Imge = "daikyou.jpg"
      }
      else{
        text = omikuji[6]
        Imge = "kichi.jpg"
      }
      
      var object = document.getElementById("omikuji");
      object.innerHTML = `<b>${text}</b><br><img src="${Imge}" alt="${text}">`;
}
     