function omikujibottun(){
      var omikuji = new Array("大吉","中吉","小吉");
      var a = Math.random()*3
      var b = Math.floor(a);
      var rand = omikuji[b];
      
      var object = document.getElementById("omikuji");
      object.innerText = rand;
}
     