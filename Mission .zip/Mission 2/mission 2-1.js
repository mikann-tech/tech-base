var object = document.getElementById('greeting');
var text = object.innerText;
alert (text);
